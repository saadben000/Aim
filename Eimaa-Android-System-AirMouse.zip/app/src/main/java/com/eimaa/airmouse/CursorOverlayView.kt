package com.eimaa.airmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * طبقة مؤشر الماوس الهوائي العائمة فوق جميع تطبيقات الهاتف (SYSTEM_ALERT_WINDOW)
 * تمرر اللمسات الحقيقية والنقرات البرمجية للتطبيقات الموجودة تحتها مباشرة.
 */
class CursorOverlayView(context: Context) : View(context) {

    private var cursorX: Float = 540f
    private var cursorY: Float = 1206f
    private var isPinching: Boolean = false
    private var isLocked: Boolean = false
    private var visible: Boolean = false

    private val density = resources.displayMetrics.density
    private val baseRadius = 24f * density

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#0284C7")
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        color = Color.WHITE
    }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * density
        color = Color.parseColor("#38BDF8")
    }

    private val arrowPath = Path()

    fun updateCursor(x: Float, y: Float, pinching: Boolean, locked: Boolean, show: Boolean) {
        cursorX = x
        cursorY = y
        isPinching = pinching
        isLocked = locked
        visible = show
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!visible) return

        val activeColor = when {
            isLocked -> Color.parseColor("#64748B")
            isPinching -> Color.parseColor("#10B981")
            else -> Color.parseColor("#0284C7")
        }
        fillPaint.color = activeColor
        ringPaint.color = activeColor

        if (true) {
            // رسم مؤشر ماوس حقيقي واضح فوق جميع تطبيقات الهاتف
            val s = baseRadius * (if (isPinching) 0.88f else 1.0f)
            arrowPath.reset()
            arrowPath.moveTo(cursorX, cursorY)
            arrowPath.lineTo(cursorX, cursorY + s * 1.45f)
            arrowPath.lineTo(cursorX + s * 0.42f, cursorY + s * 1.12f)
            arrowPath.lineTo(cursorX + s * 0.72f, cursorY + s * 1.68f)
            arrowPath.lineTo(cursorX + s * 0.96f, cursorY + s * 1.54f)
            arrowPath.lineTo(cursorX + s * 0.66f, cursorY + s * 0.98f)
            arrowPath.lineTo(cursorX + s * 1.12f, cursorY + s * 0.98f)
            arrowPath.close()

            canvas.drawPath(arrowPath, fillPaint)
            canvas.drawPath(arrowPath, strokePaint)
        } else {
            // رسم حلقة مؤشر ذكية دقيقة
            val r = if (isPinching) baseRadius * 0.65f else baseRadius
            canvas.drawCircle(cursorX, cursorY, r, ringPaint)
            canvas.drawCircle(cursorX, cursorY, 4.5f * density, fillPaint)
            canvas.drawCircle(cursorX, cursorY, 4.5f * density, strokePaint)
        }
    }
}
