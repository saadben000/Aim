package com.eimaa.airmouse

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * شاشة التفعيل السريع باللغة العربية لمنح الصلاحيات الثلاث وتشغيل الماوس الهوائي فوق كل التطبيقات.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#F8FAFC"))
        }

        val title = TextView(this).apply {
            text = "إيماءة — ماوس الهاتف الهوائي"
            textSize = 22f
            setTextColor(Color.parseColor("#0F172A"))
        }

        val subtitle = TextView(this).apply {
            text = "فعّل الصلاحيات الثلاث التالية ليظهر مؤشر الماوس فوق جميع تطبيقات هاتفك (واتساب، يوتيوب، تيك توك، المتصفح، والشاشة الرئيسية) وتتحكم بها باليدين دون لمس الشاشة."
            textSize = 14f
            setTextColor(Color.parseColor("#475569"))
            setPadding(0, 16, 0, 32)
        }

        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#0284C7"))
            setPadding(0, 0, 0, 32)
        }

        val btnCamera = createActionButton("1. منح إذن الكاميرا الأمامية") {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 101)
        }

        val btnOverlay = createActionButton("2. تفعيل الظهور فوق التطبيقات الأخرى") {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        val btnAccessibility = createActionButton("3. تفعيل خدمة الماوس من إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(statusText)
        root.addView(btnCamera)
        root.addView(btnOverlay)
        root.addView(btnAccessibility)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val camOk = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val overlayOk = Settings.canDrawOverlays(this)
        statusText.text = "حالة الصلاحيات الحالية: الكاميرا (" +
            (if (camOk) "جاهزة" else "مطلوبة") + ") · الطفو فوق التطبيقات (" +
            (if (overlayOk) "جاهز" else "مطلوب") + ")"
    }

    private fun createActionButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F172A"))
            setTextColor(Color.WHITE)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (52 * resources.displayMetrics.density).toInt()
            ).apply {
                bottomMargin = (14 * resources.displayMetrics.density).toInt()
            }
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }
}
