package com.eimaa.airmouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Path
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ServiceLifecycleDispatcher
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * الخدمة الأساسية في أندرويد:
 * 1. تشغّل الكاميرا الأمامية في الخلفية أثناء فتح أي تطبيق (واتساب، يوتيوب، تيك توك، الألعاب).
 * 2. ترسم مؤشر الماوس العائم فوق النظام بالكامل.
 * 3. تحول إيماءات اليد الواحدة واليدين معاً إلى نقرات وسحب وتكبير وأوامر نظام حقيقية.
 */
class AirMouseAccessibilityService : AccessibilityService(), LifecycleOwner {

    private val lifecycleDispatcher = ServiceLifecycleDispatcher(this)
    override val lifecycle: Lifecycle get() = lifecycleDispatcher.lifecycle

    private var windowManager: WindowManager? = null
    private var overlayView: CursorOverlayView? = null
    private var handLandmarker: HandLandmarker? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private var screenW = 1080f
    private var screenH = 2412f
    private var smoothX = screenW / 2f
    private var smoothY = screenH / 2f

    private val sensitivity = 1.45f
    private val alpha = 0.65f
    private val pinchRatioThreshold = 0.231f

    private var wasPinching = false
    private var isTouchlessLocked = false
    private var lastActionMs = 0L
    private var poseHoldStartMs = 0L
    private var currentHeldPose = ""
    private var poseTriggered = false
    private var dualPalmStartMs = 0L
    private var prevDualDist: Float? = null

    override fun onCreate() {
        lifecycleDispatcher.onServicePreSuperOnCreate()
        super.onCreate()
        val dm = resources.displayMetrics
        screenW = dm.widthPixels.toFloat()
        screenH = dm.heightPixels.toFloat()
        smoothX = screenW / 2f
        smoothY = screenH / 2f
    }

    override fun onServiceConnected() {
        lifecycleDispatcher.onServicePreSuperOnBind()
        super.onServiceConnected()
        setupFloatingOverlay()
        setupHandLandmarker()
        startFrontCamera()
    }

    private fun setupFloatingOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlayView = CursorOverlayView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        windowManager?.addView(overlayView, params)
    }

    private fun setupHandLandmarker() {
        val baseOptions = BaseOptions.builder()
            .setModelAssetPath("hand_landmarker.task")
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(baseOptions)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.55f)
            .setMinHandPresenceConfidence(0.55f)
            .setMinTrackingConfidence(0.55f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ -> onHandsDetected(result) }
            .build()

        handLandmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun startFrontCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                processImageProxy(imageProxy)
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    analysis
                )
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processImageProxy(imageProxy: ImageProxy) {
        val bitmapBuffer = Bitmap.createBitmap(
            imageProxy.width,
            imageProxy.height,
            Bitmap.Config.ARGB_8888
        )
        imageProxy.planes[0].buffer.rewind()
        bitmapBuffer.copyPixelsFromBuffer(imageProxy.planes[0].buffer)

        val matrix = Matrix().apply {
            postRotate(imageProxy.imageInfo.rotationDegrees.toFloat())
            // عكس الكاميرا الأمامية كالمرآة لمطابقة اتجاه حركة اليد
            postScale(-1f, 1f, imageProxy.width / 2f, imageProxy.height / 2f)
        }

        val rotatedBitmap = Bitmap.createBitmap(
            bitmapBuffer, 0, 0, bitmapBuffer.width, bitmapBuffer.height, matrix, true
        )
        imageProxy.close()

        val mpImage = BitmapImageBuilder(rotatedBitmap).build()
        handLandmarker?.detectAsync(mpImage, SystemClock.uptimeMillis())
    }

    private fun onHandsDetected(result: HandLandmarkerResult) {
        val hands = result.landmarks()
        val now = SystemClock.uptimeMillis()

        if (hands.isEmpty()) {
            wasPinching = false
            prevDualDist = null
            overlayView?.updateCursor(smoothX, smoothY, false, isTouchlessLocked, false)
            return
        }

        // فحص إيماءات اليدين معاً (تكبير ثنائي اللمس أو قفل الأمان برفع الكفين)
        if (hands.size >= 2) {
            val h1Open = isOpenPalm(hands[0])
            val h2Open = isOpenPalm(hands[1])
            if (h1Open && h2Open) {
                if (dualPalmStartMs == 0L) dualPalmStartMs = now
                if (now - dualPalmStartMs > 850L && now - lastActionMs > 1400L) {
                    isTouchlessLocked = !isTouchlessLocked
                    lastActionMs = now
                    dualPalmStartMs = 0L
                }
                overlayView?.updateCursor(smoothX, smoothY, false, isTouchlessLocked, true)
                return
            } else {
                dualPalmStartMs = 0L
            }

            if (!isTouchlessLocked && isHandPinching(hands[0]) && isHandPinching(hands[1])) {
                val d = hypot(
                    hands[0][8].x() - hands[1][8].x(),
                    hands[0][8].y() - hands[1][8].y()
                )
                prevDualDist?.let { prev ->
                    if (abs(d - prev) > 0.06f && now - lastActionMs > 500L) {
                        performTwoFingerZoom(smoothX, smoothY, expand = d > prev)
                        lastActionMs = now
                        prevDualDist = d
                    }
                } ?: run { prevDualDist = d }
                overlayView?.updateCursor(smoothX, smoothY, true, false, true)
                return
            } else {
                prevDualDist = null
            }
        }

        // تحريك مؤشر الماوس عبر اليد الأساسية
        val lm = hands[0]
        val rawX = lm[8].x() * 0.72f + lm[5].x() * 0.28f
        val rawY = lm[8].y() * 0.72f + lm[5].y() * 0.28f

        val normX = min(1f, max(0f, (rawX - 0.5f) * sensitivity + 0.5f))
        val normY = min(1f, max(0f, (rawY - 0.5f) * sensitivity + 0.5f))

        smoothX += (normX * screenW - smoothX) * alpha
        smoothY += (normY * screenH - smoothY) * alpha

        val pinching = isHandPinching(lm)
        overlayView?.updateCursor(smoothX, smoothY, pinching, isTouchlessLocked, true)

        if (isTouchlessLocked) return

        // نقرة الماوس الفورية عند ضم الإبهام والسبابة
        if (pinching) {
            if (!wasPinching && now - lastActionMs > 260L) {
                performTap(smoothX, smoothY)
                lastActionMs = now
            }
            wasPinching = true
            return
        }
        wasPinching = false

        // أوامر النظام السريعة عبر ثبات شكل اليد
        val pose = classifyStaticPose(lm)
        if (pose.isNotEmpty()) {
            if (pose != currentHeldPose) {
                currentHeldPose = pose
                poseHoldStartMs = now
                poseTriggered = false
            } else if (!poseTriggered && now - poseHoldStartMs > 520L && now - lastActionMs > 950L) {
                poseTriggered = true
                lastActionMs = now
                when (pose) {
                    "OPEN_PALM" -> performGlobalAction(GLOBAL_ACTION_HOME)
                    "FIST" -> performGlobalAction(GLOBAL_ACTION_BACK)
                    "PEACE" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                    "THUMBS_UP" -> adjustVolume(raise = true)
                    "THUMBS_DOWN" -> adjustVolume(raise = false)
                }
            }
        } else {
            currentHeldPose = ""
            poseTriggered = false
        }
    }

    private fun isHandPinching(lm: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Boolean {
        val palm = max(0.06f, hypot(lm[0].x() - lm[9].x(), lm[0].y() - lm[9].y()))
        val pinchDist = hypot(lm[4].x() - lm[8].x(), lm[4].y() - lm[8].y())
        return (pinchDist / (palm * 2.1f)) < pinchRatioThreshold
    }

    private fun isOpenPalm(lm: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Boolean {
        val w = lm[0]
        val iExt = hypot(lm[8].x() - w.x(), lm[8].y() - w.y()) > hypot(lm[6].x() - w.x(), lm[6].y() - w.y()) * 1.14f
        val mExt = hypot(lm[12].x() - w.x(), lm[12].y() - w.y()) > hypot(lm[10].x() - w.x(), lm[10].y() - w.y()) * 1.14f
        val rExt = hypot(lm[16].x() - w.x(), lm[16].y() - w.y()) > hypot(lm[14].x() - w.x(), lm[14].y() - w.y()) * 1.12f
        val pExt = hypot(lm[20].x() - w.x(), lm[20].y() - w.y()) > hypot(lm[18].x() - w.x(), lm[18].y() - w.y()) * 1.12f
        return iExt && mExt && rExt && pExt
    }

    private fun classifyStaticPose(lm: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): String {
        val w = lm[0]
        val palm = max(0.06f, hypot(w.x() - lm[9].x(), w.y() - lm[9].y()))
        val iExt = hypot(lm[8].x() - w.x(), lm[8].y() - w.y()) > hypot(lm[6].x() - w.x(), lm[6].y() - w.y()) * 1.14f
        val mExt = hypot(lm[12].x() - w.x(), lm[12].y() - w.y()) > hypot(lm[10].x() - w.x(), lm[10].y() - w.y()) * 1.14f
        val rExt = hypot(lm[16].x() - w.x(), lm[16].y() - w.y()) > hypot(lm[14].x() - w.x(), lm[14].y() - w.y()) * 1.12f
        val pExt = hypot(lm[20].x() - w.x(), lm[20].y() - w.y()) > hypot(lm[18].x() - w.x(), lm[18].y() - w.y()) * 1.12f

        if (iExt && mExt && rExt && pExt) return "OPEN_PALM"
        if (iExt && mExt && !rExt && !pExt) return "PEACE"
        if (!iExt && !mExt && !rExt && !pExt) {
            val thumbSep = hypot(lm[4].x() - lm[6].x(), lm[4].y() - lm[6].y())
            if (thumbSep > palm * 0.58f) {
                return if (lm[3].y() - lm[4].y() > palm * 0.2f) "THUMBS_UP" else "THUMBS_DOWN"
            }
            return "FIST"
        }
        return ""
    }

    private fun performTap(x: Float, y: Float) {
        val safeX = min(screenW - 5f, max(5f, x))
        val safeY = min(screenH - 5f, max(5f, y))
        val path = Path().apply { moveTo(safeX, safeY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 55L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun performTwoFingerZoom(cx: Float, cy: Float, expand: Boolean) {
        val startOffset = if (expand) 60f else 220f
        val endOffset = if (expand) 220f else 60f

        val p1 = Path().apply {
            moveTo(max(10f, cx - startOffset), cy)
            lineTo(max(10f, cx - endOffset), cy)
        }
        val p2 = Path().apply {
            moveTo(min(screenW - 10f, cx + startOffset), cy)
            lineTo(min(screenW - 10f, cx + endOffset), cy)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p1, 0L, 260L))
            .addStroke(GestureDescription.StrokeDescription(p2, 0L, 260L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun adjustVolume(raise: Boolean) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = if (raise) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        lifecycleDispatcher.onServicePreSuperOnDestroy()
        overlayView?.let { windowManager?.removeView(it) }
        handLandmarker?.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
