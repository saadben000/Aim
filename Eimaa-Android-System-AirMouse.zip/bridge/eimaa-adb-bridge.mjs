#!/usr/bin/env node
/**
 * جسر «إيماءة» للتحكم الشامل بجميع تطبيقات الهاتف (عبر ADB / Termux بدون روت)
 * يعمل بدون أي مكتبات خارجية (Zero Dependencies) باستخدام Node.js المدمج فقط!
 *
 * التشغيل على الهاتف مباشرة عبر Termux (أندرويد 11+):
 *   pkg install nodejs android-tools -y
 *   adb connect 127.0.0.1:<منفذ_التصحيح_اللاسلكي>
 *   node eimaa-adb-bridge.mjs
 *
 * أو التشغيل على الكمبيوتر المتصل بالهاتف عبر USB / Wi-Fi:
 *   node eimaa-adb-bridge.mjs
 */

import http from 'node:http';
import crypto from 'node:crypto';
import { exec } from 'node:child_process';

const PORT = Number(process.env.PORT || 8765);

function runAdb(cmd) {
  exec(`adb shell ${cmd}`, { timeout: 2500 }, (err) => {
    if (err) {
      console.error('[ADB Notice]:', err.message.split('\n')[0]);
    }
  });
}

function encodeWsFrame(obj) {
  const payload = Buffer.from(JSON.stringify(obj), 'utf8');
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x81, len]);
  } else {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  }
  return Buffer.concat([header, payload]);
}

function decodeWsFrames(buffer) {
  const messages = [];
  let offset = 0;
  while (offset + 2 <= buffer.length) {
    const opcode = buffer[offset] & 0x0f;
    if (opcode === 0x8) return { close: true, messages };
    const masked = (buffer[offset + 1] & 0x80) !== 0;
    let len = buffer[offset + 1] & 0x7f;
    let cursor = offset + 2;
    if (len === 126) {
      if (cursor + 2 > buffer.length) break;
      len = buffer.readUInt16BE(cursor);
      cursor += 2;
    } else if (len === 127) {
      if (cursor + 8 > buffer.length) break;
      len = Number(buffer.readBigUInt64BE(cursor));
      cursor += 8;
    }
    const maskLen = masked ? 4 : 0;
    if (cursor + maskLen + len > buffer.length) break;
    const payload = Buffer.alloc(len);
    if (masked) {
      const mask = buffer.subarray(cursor, cursor + 4);
      cursor += 4;
      for (let i = 0; i < len; i++) {
        payload[i] = buffer[cursor + i] ^ mask[i % 4];
      }
    } else {
      buffer.copy(payload, 0, cursor, cursor + len);
    }
    offset = cursor + len;
    if (opcode === 0x1) {
      messages.push(payload.toString('utf8'));
    }
  }
  return { close: false, messages };
}

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Eimaa Touchless ADB Bridge is running on ws://127.0.0.1:' + PORT);
});

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key) {
    socket.destroy();
    return;
  }
  const accept = crypto
    .createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
    .digest('base64');

  socket.write(
    [
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${accept}`,
      '\r\n',
    ].join('\r\n')
  );

  console.log('✅ تم اتصال تطبيق إيماءة بجسر النظام بنجاح!');

  socket.on('data', (chunk) => {
    const { close, messages } = decodeWsFrames(chunk);
    if (close) {
      socket.end();
      return;
    }
    for (const raw of messages) {
      try {
        const msg = JSON.parse(raw);
        if (msg.type === 'tap') {
          console.log(`🖱️ نقر في الهاتف: (${msg.x}, ${msg.y})`);
          runAdb(`input tap ${Math.round(msg.x)} ${Math.round(msg.y)}`);
        } else if (msg.type === 'swipe') {
          console.log(`👆 سحب الشاشة: (${msg.x1},${msg.y1}) -> (${msg.x2},${msg.y2})`);
          runAdb(
            `input swipe ${Math.round(msg.x1)} ${Math.round(msg.y1)} ${Math.round(msg.x2)} ${Math.round(msg.y2)} ${msg.duration || 220}`
          );
        } else if (msg.type === 'key') {
          console.log(`🔘 زر نظام: ${msg.name} (${msg.keycode})`);
          runAdb(`input keyevent ${Number(msg.keycode)}`);
        } else if (msg.type === 'statusbar') {
          runAdb(`cmd statusbar ${msg.cmd === 'expand-notifications' ? 'expand-notifications' : 'collapse'}`);
        }
        if (msg.type !== 'move' && msg.ts) {
          socket.write(encodeWsFrame({ type: 'ack', ts: msg.ts }));
        }
      } catch (e) {
        // ignore malformed json
      }
    }
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('====================================================');
  console.log('🚀 جسر «إيماءة» للتحكم بجميع تطبيقات الهاتف يعمل الآن!');
  console.log(`📡 العنوان المحلي: ws://127.0.0.1:${PORT}`);
  console.log('افتح أي تطبيق في هاتفك (واتساب، يوتيوب، تيك توك) وتحكم به باليدين!');
  console.log('====================================================');
});
